-- Canvas Items table for project moodboard/workspace
CREATE TABLE IF NOT EXISTS canvas_items (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  type TEXT NOT NULL DEFAULT 'text' CHECK (type IN ('text', 'image')),
  x INTEGER NOT NULL DEFAULT 2,
  y INTEGER NOT NULL DEFAULT 2,
  w INTEGER NOT NULL DEFAULT 10,
  h INTEGER NOT NULL DEFAULT 6,
  content TEXT DEFAULT '',
  color TEXT DEFAULT '#7ACF85',
  image_url TEXT DEFAULT '',
  label TEXT DEFAULT '',
  sort_order INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Enable RLS (open access like other tables)
ALTER TABLE canvas_items ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Allow all access to canvas_items" ON canvas_items FOR ALL USING (true) WITH CHECK (true);

-- Enable realtime
ALTER PUBLICATION supabase_realtime ADD TABLE canvas_items;

-- Index for fast lookups by project
CREATE INDEX IF NOT EXISTS idx_canvas_items_project ON canvas_items(project_id);
