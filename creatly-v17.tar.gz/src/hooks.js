import { useState, useEffect, useRef } from 'react';
import { supabase } from './supabase.js';

// ─── useProjects ───────────────────────────────────────────────────────────────
export function useProjects() {
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchProjects();

    const channel = supabase
      .channel('projects-realtime')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'projects' }, () => {
        fetchProjects();
      })
      .subscribe();

    return () => supabase.removeChannel(channel);
  }, []);

  async function fetchProjects() {
    const { data, error } = await supabase
      .from('projects')
      .select('*')
      .order('created_at', { ascending: false });
    if (!error) setProjects(data || []);
    setLoading(false);
  }

  async function addProject(project) {
    const { data, error } = await supabase
      .from('projects')
      .insert([project])
      .select()
      .single();
    if (!error) setProjects(prev => [data, ...prev]);
    return { data, error };
  }

  async function updateProject(id, updates) {
    const { data, error } = await supabase
      .from('projects')
      .update({ ...updates, updated_at: new Date().toISOString() })
      .eq('id', id)
      .select()
      .single();
    if (!error) setProjects(prev => prev.map(p => p.id === id ? data : p));
    return { data, error };
  }

  async function deleteProject(id) {
    const { error } = await supabase.from('projects').delete().eq('id', id);
    if (!error) setProjects(prev => prev.filter(p => p.id !== id));
    return { error };
  }

  return { projects, loading, addProject, updateProject, deleteProject, refetch: fetchProjects };
}

// ─── useTagColors ──────────────────────────────────────────────────────────────
export function useTagColors() {
  const [tagColors, setTagColors] = useState({});

  useEffect(() => {
    fetchTagColors();

    const channel = supabase
      .channel('tag-colors-realtime')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'tag_colors' }, () => {
        fetchTagColors();
      })
      .subscribe();

    return () => supabase.removeChannel(channel);
  }, []);

  async function fetchTagColors() {
    const { data, error } = await supabase.from('tag_colors').select('*');
    if (!error) {
      const map = {};
      (data || []).forEach(row => { map[row.tag] = row.color; });
      setTagColors(map);
    }
  }

  async function setTagColor(tag, color) {
    const { error } = await supabase
      .from('tag_colors')
      .upsert([{ tag, color }], { onConflict: 'tag' });
    if (!error) setTagColors(prev => ({ ...prev, [tag]: color }));
    return { error };
  }

  return { tagColors, setTagColor };
}

// ─── useAppSettings ────────────────────────────────────────────────────────────
export function useAppSettings() {
  const [settings, setSettings] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchSettings();
  }, []);

  async function fetchSettings() {
    const { data, error } = await supabase
      .from('app_settings')
      .select('*')
      .eq('id', 'global')
      .single();
    if (!error && data) setSettings(data);
    setLoading(false);
  }

  async function updateSettings(updates) {
    const { data, error } = await supabase
      .from('app_settings')
      .upsert([{ id: 'global', ...updates }])
      .select()
      .single();
    if (!error) setSettings(data);
    return { data, error };
  }

  return { settings, loading, updateSettings };
}

// ─── useDocs ───────────────────────────────────────────────────────────────────
export function useDocs() {
  const [docs, setDocs] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDocs();

    const channel = supabase
      .channel('docs-realtime')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'docs' }, () => {
        fetchDocs();
      })
      .subscribe();

    return () => supabase.removeChannel(channel);
  }, []);

  async function fetchDocs() {
    const { data, error } = await supabase
      .from('docs')
      .select('*')
      .order('updated_at', { ascending: false });
    if (!error) setDocs(data || []);
    setLoading(false);
  }

  async function addDoc(doc) {
    const { data, error } = await supabase
      .from('docs')
      .insert([doc])
      .select()
      .single();
    if (!error) setDocs(prev => [data, ...prev]);
    return { data, error };
  }

  async function updateDoc(id, updates) {
    const { data, error } = await supabase
      .from('docs')
      .update({ ...updates, updated_at: new Date().toISOString() })
      .eq('id', id)
      .select()
      .single();
    if (!error) setDocs(prev => prev.map(d => d.id === id ? data : d));
    return { data, error };
  }

  async function deleteDoc(id) {
    const { error } = await supabase.from('docs').delete().eq('id', id);
    if (!error) setDocs(prev => prev.filter(d => d.id !== id));
    return { error };
  }

  return { docs, loading, addDoc, updateDoc, deleteDoc, refetch: fetchDocs };
}

// ─── useClients ────────────────────────────────────────────────────────────────
export function useClients() {
  const [clients, setClients] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchClients();

    const channel = supabase
      .channel('clients-realtime')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'clients' }, () => {
        fetchClients();
      })
      .subscribe();

    return () => supabase.removeChannel(channel);
  }, []);

  async function fetchClients() {
    const { data, error } = await supabase
      .from('clients')
      .select('*')
      .order('created_at', { ascending: false });
    if (!error) setClients(data || []);
    setLoading(false);
  }

  async function addClient(client) {
    const { data, error } = await supabase
      .from('clients')
      .insert([client])
      .select()
      .single();
    if (!error) setClients(prev => [data, ...prev]);
    return { data, error };
  }

  async function updateClient(id, updates) {
    const { data, error } = await supabase
      .from('clients')
      .update({ ...updates, updated_at: new Date().toISOString() })
      .eq('id', id)
      .select()
      .single();
    if (!error) setClients(prev => prev.map(c => c.id === id ? data : c));
    return { data, error };
  }

  async function deleteClient(id) {
    const { error } = await supabase.from('clients').delete().eq('id', id);
    if (!error) setClients(prev => prev.filter(c => c.id !== id));
    return { error };
  }

  return { clients, loading, addClient, updateClient, deleteClient, refetch: fetchClients };
}

// ─── useServices ──────────────────────────────────────────────────────────────
export function useServices() {
  const [services, setServices] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchServices();

    const channel = supabase
      .channel('services-realtime')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'services' }, () => {
        fetchServices();
      })
      .subscribe();

    return () => supabase.removeChannel(channel);
  }, []);

  async function fetchServices() {
    const { data, error } = await supabase
      .from('services')
      .select('*')
      .order('created_at', { ascending: false });
    if (!error) setServices(data || []);
    setLoading(false);
  }

  async function addService(service) {
    const { data, error } = await supabase
      .from('services')
      .insert([service])
      .select()
      .single();
    if (!error) setServices(prev => [data, ...prev]);
    return { data, error };
  }

  async function updateService(id, updates) {
    const { data, error } = await supabase
      .from('services')
      .update({ ...updates, updated_at: new Date().toISOString() })
      .eq('id', id)
      .select()
      .single();
    if (!error) setServices(prev => prev.map(s => s.id === id ? data : s));
    return { data, error };
  }

  async function deleteService(id) {
    const { error } = await supabase.from('services').delete().eq('id', id);
    if (!error) setServices(prev => prev.filter(s => s.id !== id));
    return { error };
  }

  return { services, loading, addService, updateService, deleteService, refetch: fetchServices };
}

// ─── useNotifications ─────────────────────────────────────────────────────────
export function useNotifications(currentUser) {
  const [notifications, setNotifications] = useState([]);

  useEffect(() => {
    if (!currentUser) return;
    fetchNotifications();

    const channel = supabase
      .channel('notifications-realtime')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'notifications' }, () => {
        fetchNotifications();
      })
      .subscribe();

    return () => supabase.removeChannel(channel);
  }, [currentUser]);

  async function fetchNotifications() {
    const { data, error } = await supabase
      .from('notifications')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(50);
    if (!error) setNotifications(data || []);
  }

  async function markAllRead() {
    const { error } = await supabase
      .from('notifications')
      .update({ read: true })
      .eq('read', false);
    if (!error) setNotifications(prev => prev.map(n => ({ ...n, read: true })));
  }

  async function addNotification(notif) {
    const { error } = await supabase.from('notifications').insert([notif]);
    return { error };
  }

  const unreadCount = notifications.filter(n => !n.read).length;

  return { notifications, unreadCount, markAllRead, addNotification, refetch: fetchNotifications };
}

// ─── useIdeas ─────────────────────────────────────────────────────────────────
export function useIdeas() {
  const [ideas, setIdeas] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchIdeas();

    const channel = supabase
      .channel('ideas-realtime')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'ideas' }, () => {
        fetchIdeas();
      })
      .subscribe();

    return () => supabase.removeChannel(channel);
  }, []);

  async function fetchIdeas() {
    const { data, error } = await supabase
      .from('ideas')
      .select('*')
      .order('created_at', { ascending: false });
    if (!error) setIdeas(data || []);
    setLoading(false);
  }

  async function addIdea(idea) {
    const { data, error } = await supabase
      .from('ideas')
      .insert([idea])
      .select()
      .single();
    if (!error) setIdeas(prev => [data, ...prev]);
    return { data, error };
  }

  async function updateIdea(id, updates) {
    const { data, error } = await supabase
      .from('ideas')
      .update({ ...updates, updated_at: new Date().toISOString() })
      .eq('id', id)
      .select()
      .single();
    if (!error) setIdeas(prev => prev.map(i => i.id === id ? data : i));
    return { data, error };
  }

  async function deleteIdea(id) {
    const { error } = await supabase.from('ideas').delete().eq('id', id);
    if (!error) setIdeas(prev => prev.filter(i => i.id !== id));
    return { error };
  }

  return { ideas, loading, addIdea, updateIdea, deleteIdea, refetch: fetchIdeas };
}

// ─── Ideas Hook ───────────────────────────────────────────────────────────────
export function useIdeas() {
  const [ideas, setIdeas] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetch = async () => {
      const { data, error } = await supabase
        .from('ideas')
        .select('*')
        .order('created_at', { ascending: false })
      if (!error && data) setIdeas(data)
      setLoading(false)
    }
    fetch()
  }, [])

  useEffect(() => {
    const channel = supabase
      .channel('ideas-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'ideas' }, (payload) => {
        if (payload.eventType === 'INSERT') {
          setIdeas(prev => {
            if (prev.find(i => i.id === payload.new.id)) return prev
            return [payload.new, ...prev]
          })
        } else if (payload.eventType === 'UPDATE') {
          setIdeas(prev => prev.map(i => i.id === payload.new.id ? payload.new : i))
        } else if (payload.eventType === 'DELETE') {
          setIdeas(prev => prev.filter(i => i.id !== payload.old.id))
        }
      })
      .subscribe()
    return () => supabase.removeChannel(channel)
  }, [])

  const saveIdea = useCallback(async (idea, userId) => {
    const row = { ...idea, updated_at: new Date().toISOString() }
    const { error } = await supabase.from('ideas').upsert(row)
    if (error) console.error('Save idea error:', error)
    setIdeas(prev => {
      const idx = prev.findIndex(i => i.id === idea.id)
      if (idx >= 0) { const next = [...prev]; next[idx] = row; return next }
      return [row, ...prev]
    })
  }, [])

  const deleteIdea = useCallback(async (id) => {
    const { error } = await supabase.from('ideas').delete().eq('id', id)
    if (error) console.error('Delete idea error:', error)
    setIdeas(prev => prev.filter(i => i.id !== id))
  }, [])

  return { ideas, loading, saveIdea, deleteIdea }
}
